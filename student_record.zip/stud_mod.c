#include <stdio.h>
#include <string.h>
#include "stud.h"
void stud_mod(void)
{
struct student *temp;
char choice, field;
int roll;
char name[50];
float percentage;
if (head == NULL)
{
printf("No Records Found!\n");
return;
}
printf("\nR/r : Roll Number\n");
printf("N/n : Name\n");
printf("P/p : Percentage\n");
printf("Enter Your Choice: ");
scanf(" %c", &choice);
if (choice == 'R' || choice == 'r')
{
printf("Enter Roll Number: ");
scanf("%d", &roll);
}
else if (choice == 'N' || choice == 'n')
{
printf("Enter Name: ");
scanf(" %[^\n]", name);temp = head;
while (temp != NULL)
{
if (strcmp(temp->name, name) == 0)
printf("%d\t%s\t%.2f\n",
temp->roll, temp->name,
temp->percentage);
temp = temp->next;
}
printf("Enter Roll Number: ");
scanf("%d", &roll);
}
else if (choice == 'P' || choice == 'p')
{
printf("Enter Percentage: ");
scanf("%f", &percentage);
temp = head;
while (temp != NULL)
{
if (temp->percentage == percentage)
printf("%d\t%s\t%.2f\n",
temp->roll, temp->name,
temp->percentage);
temp = temp->next;
}
printf("Enter Roll Number: ");
scanf("%d", &roll);
}
else
{
printf("Invalid Choice!\n");return;
}
temp = head;
while (temp != NULL)
{
if (temp->roll == roll)
{
printf("\nN/n : Modify Name\n");
printf("P/p : Modify Percentage\n");
printf("Enter Your Choice: ");
scanf(" %c", &field);
if (field == 'N' || field == 'n')
{
printf("Enter New Name: ");
scanf(" %[^\n]", temp->name);
}
else if (field == 'P' || field == 'p')
{
printf("Enter New Percentage: ");
scanf("%f", &temp->percentage);
}
else
{
printf("Invalid Choice!\n");
return;
}
printf("Record Modified Successfully!\n");
return;
}
temp = temp->next;
}
printf("Record Not Found!\n");
}
