#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "stud.h"
void stud_save(void)
{
struct student *temp;
FILE *fp;
fp = fopen("student.dat", "wb");
if (fp == NULL)
{
printf("File Opening Error!\n");
return;
}
temp = head;
while (temp != NULL)
{
fwrite(temp, sizeof(struct student), 1, fp);
temp = temp->next;
}
fclose(fp);
}
void stud_load(void)
{
struct student data;
struct student *newnode, *temp;
FILE *fp;
fp = fopen("student.dat", "rb");if (fp == NULL)
return;
while (fread(&data, sizeof(struct student), 1, fp) == 1)
{
newnode = malloc(sizeof(struct student));
if (newnode == NULL)
break;
newnode->roll = data.roll;
strcpy(newnode->name, data.name);
newnode->percentage = data.percentage;
newnode->next = NULL;
if (head == NULL)
{
head = newnode;
}
else
{
temp = head;
while (temp->next != NULL)
temp = temp->next;
temp->next = newnode;
}
}
fclose(fp);
}
