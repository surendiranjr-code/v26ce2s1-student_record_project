#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"stud.h"

void stud_add(void)
{
struct student *newnode, *temp;
int roll = 1;
newnode = malloc(sizeof(struct student));
if (newnode == NULL)
{
printf("Memory Allocation Failed!\n");
return;
}
/* Find smallest available roll number */
while (1)
{
temp = head;
while (temp != NULL)
{
if (temp->roll == roll)break;
temp = temp->next;
}
if (temp == NULL)
break;
roll++;
}
newnode->roll = roll;
printf("Enter Student Name: ");
scanf(" %[^\n]", newnode->name);
printf("Enter Percentage: ");
scanf("%f", &newnode->percentage);
newnode->next = NULL;
if (head == NULL)
{
head = newnode;
}
else
{
temp = head;
while (temp->next != NULL)
temp = temp->next;
temp->next = newnode;
}
printf("Record Added Successfully!\n");
printf("Roll Number: %d\n", roll);
}
