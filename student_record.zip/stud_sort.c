#include <stdio.h>
#include <string.h>
#include "stud.h"
void stud_sort(void)
{
struct student *i, *j;
int roll;
char name[50];
float percentage;
char choice;
if (head == NULL)
{
printf("No Records Found!\n");
return;
}
printf("\nN/n : Sort by Name\n");
printf("P/p : Sort by Percentage\n");
printf("Enter Your Choice: ");
scanf(" %c", &choice);
for (i = head; i != NULL; i = i->next)
{
for (j = i->next; j != NULL; j = j->next)
{
int swap = 0;
if (choice == 'N' || choice == 'n')
{
if (strcmp(i->name, j->name) > 0)
swap = 1;
}
else if (choice == 'P' || choice == 'p')
{
if (i->percentage > j->percentage)
swap = 1;
}
else
{
printf("Invalid Choice!\n");
return;}
if (swap)
{
roll = i->roll;
i->roll = j->roll;
j->roll = roll;
strcpy(name, i->name);
strcpy(i->name, j->name);
strcpy(j->name, name);
percentage = i->percentage;
i->percentage = j->percentage;
j->percentage = percentage;
}
}
}
printf("Records Sorted Successfully!\n");
stud_show();
}
